__all__ = ["super_print"]


def super_print() -> None:
    """Print an underlined string."""
    print("\033[4msuper_print\033[0m")
